package com.example.voicearena

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Навыки «умной колонки», которые работают без интернета и без Claude:
 * время, заряд, фонарик, громкость, музыка, таймеры, будильник, калькулятор, погода и др.
 * handle() возвращает true, если фраза обработана; ответ передаётся в say().
 */
object Skills {

    private var torchOn = false

    private val STOP_WORDS = setOf(
        "стоп", "хватит", "замолчи", "тихо", "помолчи", "молчи", "остановись", "пауза",
        "поставь на паузу", "останови музыку", "выключи музыку"
    )

    private val JOKES = listOf(
        "Жена просит программиста: купи батон хлеба, и если будут яйца, возьми десяток. " +
            "Он возвращается с десятью батонами. Объясняет: яйца были.",
        "Почему программисты не любят природу? Там слишком много багов.",
        "Звонят в поддержку: у меня пропал интернет. Спрашивают: роутер включён? " +
            "Отвечает: я не пользуюсь роутером, у меня вайфай.",
        "Если вы ищете ответ в интернете и находите собственный вопрос двухлетней давности, " +
            "значит, вы программист.",
        "Заходит робот в бар, а бармен ему: у нас роботов не обслуживают. " +
            "Робот: ничего страшного, я просто подзаряжусь."
    )

    private val NUM_WORDS = mapOf(
        "ноль" to 0, "один" to 1, "одну" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3,
        "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9,
        "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12, "тринадцать" to 13,
        "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16, "семнадцать" to 17,
        "восемнадцать" to 18, "девятнадцать" to 19, "двадцать" to 20, "тридцать" to 30,
        "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60
    )

    private val TIMER_RE = Regex("""(?:таймер|засеки|отсчитай)\s+(?:на\s+)?(?:(.+?)\s+)?(секунд[а-я]*|минут[а-я]*|час[а-я]*)""")
    private val REMIND_RE = Regex("""(?:напомни(?:ть)?(?:\s+мне)?|разбуди(?:\s+меня)?|поставь\s+будильник|будильник)\s+через\s+(?:(.+?)\s+)?(секунд[а-я]*|минут[а-я]*|час[а-я]*)\s*(.*)""")
    private val ALARM_RE = Regex("""(?:на|в|к)\s+(\d{1,2})(?:[:.\s]\s*(\d{2}))?\s*(утра|вечера|дня|ночи)?""")
    private val NEXT_RE = Regex("""следующ[а-я]*\s+(?:трек|песн[а-я]*|композици[а-я]*)|^дальше$|^пропусти(?:\s+трек|\s+песню)?$|переключи\s+(?:трек|песню)""")
    private val PREV_RE = Regex("""предыдущ[а-я]*\s+(?:трек|песн[а-я]*|композици[а-я]*)|верни\s+(?:трек|песню)""")
    private val PLAY_RE = Regex("""^(?:продолжи|продолжай|играй|воспроизведи|включи музыку|продолжи музыку)$""")
    private val MUSIC_RE = Regex("""^(?:включи|поставь|сыграй|запусти|найди)\s+(?:песню|трек|композицию|музыку|исполнителя|группу|альбом)\s+(.+)$|^сыграй\s+(.+)$""")
    private val NAV_RE = Regex("""(?:маршрут|навигаци[а-я]*|доехать|добраться|дойти)\s+(?:до|в|на|к)\s+(.+)$""")
    private val MAP_RE = Regex("""(?:найди на карте|покажи на карте|где находится)\s+(.+)$""")
    private val NOTE_RE = Regex("""^(?:запомни|запиши)\s+(?:что\s+)?(.+)$""")
    private val CALC_RE = Regex("""(?:сколько будет|посчитай|вычисли|чему равно)\s+(.+)""")
    private val CITY_RE = Regex("""(?:^|\s)в\s+(?:городе\s+)?([а-я\- ]+)$""")
    private val RANDOM_RE = Regex("""случайное число от\s+(\d+)\s+до\s+(\d+)""")

    fun handle(context: Context, raw: String, say: (String) -> Unit): Boolean {
        val t = normalize(raw)
        if (t.isEmpty()) return false

        // --- стоп ---
        if (t in STOP_WORDS) {
            Speaker.stop()
            mediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE)
            say("")
            return true
        }

        // --- разговор ---
        if (has(t, "что ты умеешь", "что умеешь", "список команд", "твои команды")) {
            say(
                "Я умею открывать приложения и нажимать кнопки, ставить таймеры и будильники, " +
                    "называть время, дату и погоду, включать фонарик, менять громкость и управлять музыкой, " +
                    "считать, строить маршруты, запоминать заметки, шутить и отвечать на вопросы."
            )
            return true
        }
        if (Regex("""^(?:привет|здравствуй|здравствуйте|добрый день|добрый вечер|доброе утро|хай)(?:\s+джарвис)?$""").matches(t)) {
            say(greeting())
            return true
        }
        if (has(t, "как дела", "как жизнь", "как ты")) {
            say("Отлично, все системы в норме. Чем могу помочь?")
            return true
        }
        if (has(t, "кто ты", "как тебя зовут", "ты кто")) {
            say("Я Джарвис, ваш голосовой помощник.")
            return true
        }
        if (t.startsWith("спасибо") || t == "благодарю") {
            say("Всегда пожалуйста.")
            return true
        }

        // --- время и дата ---
        if (has(t, "который час", "сколько времени", "скажи время", "текущее время", "сколько сейчас время")) {
            say("Сейчас " + SimpleDateFormat("H:mm", Locale("ru")).format(Date()))
            return true
        }
        if (has(
                t, "какое сегодня число", "какой сегодня день", "какая сегодня дата",
                "какой день недели", "какое число"
            )
        ) {
            say("Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy 'года'", Locale("ru")).format(Date()))
            return true
        }

        // --- телефон ---
        if (has(t, "заряд", "батаре", "сколько процентов")) return battery(context, say)

        if (has(t, "фонарик", "фонарь", "вспышк")) {
            val off = has(t, "выключи", "погаси", "отключи", "убери")
            val ok = setTorch(context, !off)
            say(if (!ok) "Не удалось управлять фонариком" else if (off) "Фонарик выключен" else "Фонарик включён")
            return true
        }

        if (has(t, "громкост", "громче", "тише", "без звука", "выключи звук", "отключи звук", "включи звук")) {
            return volume(context, t, say)
        }

        // --- музыка ---
        if (NEXT_RE.containsMatchIn(t)) {
            mediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT)
            say("")
            return true
        }
        if (PREV_RE.containsMatchIn(t)) {
            mediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            say("")
            return true
        }
        if (PLAY_RE.matches(t)) {
            mediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY)
            say("")
            return true
        }
        val music = MUSIC_RE.find(t)
        if (music != null) {
            val query = music.groupValues[1].ifBlank { music.groupValues[2] }.trim()
            return playMusic(context, query, say)
        }

        // --- таймеры, напоминания, будильники ---
        if (has(t, "таймер", "засеки", "отсчитай", "напомни", "будильник", "разбуди")) {
            val handled = timerSkill(context, t, say)
            if (handled) return true
        }

        // --- заметки (память) ---
        val note = NOTE_RE.find(t)
        if (note != null) {
            Prefs(context).addNote(note.groupValues[1])
            say("Запомнил.")
            return true
        }
        if (has(t, "что ты помнишь", "мои заметки", "что я просил запомнить", "прочитай заметки")) {
            val notes = Prefs(context).notes()
            say(if (notes.isEmpty()) "Пока ничего не запомнил." else "Вы просили запомнить: " + notes.joinToString(". "))
            return true
        }
        if (has(t, "забудь все", "очисти память", "удали заметки", "удали все заметки")) {
            Prefs(context).clearNotes()
            say("Память очищена.")
            return true
        }

        // --- счёт и игры ---
        if (calc(t, say)) return true

        if (has(t, "орел или решка", "подбрось монет", "кинь монет")) {
            say(if (Random.nextBoolean()) "Орёл" else "Решка")
            return true
        }
        if (has(t, "брось кубик", "кинь кубик", "подбрось кубик")) {
            say("Выпало ${Random.nextInt(1, 7)}")
            return true
        }
        val random = RANDOM_RE.find(t)
        if (random != null) {
            val a = random.groupValues[1].toIntOrNull()
            val b = random.groupValues[2].toIntOrNull()
            if (a != null && b != null && b >= a && b < Int.MAX_VALUE) {
                say("Выпало ${Random.nextInt(a, b + 1)}")
                return true
            }
        }
        if (has(t, "анекдот", "шутк", "пошути", "рассмеши", "что нибудь смешное")) {
            say(JOKES.random())
            return true
        }

        // --- погода ---
        val askWeather = has(t, "погод", "прогноз") ||
            (has(t, "температур") && has(t, "на улице", "сколько", "какая", "сейчас")) ||
            (has(t, "дожд", "зонт", "снег") && has(t, "будет", "пойдет", "нужен", " ли"))
        if (askWeather) {
            return weather(context, t, say)
        }

        // --- карты и маршруты ---
        val nav = NAV_RE.find(t)
        if (nav != null) return navigate(context, nav.groupValues[1].trim(), say)
        val map = MAP_RE.find(t)
        if (map != null) return showOnMap(context, map.groupValues[1].trim(), say)

        return false
    }

    // ---------------- вспомогательное ----------------

    private fun normalize(raw: String): String =
        raw.lowercase(Locale("ru")).replace('ё', 'е').trim().trim { it == '.' || it == '!' || it == '?' || it == ',' || it == ' ' }

    private fun has(t: String, vararg words: String): Boolean = words.any { t.contains(it) }

    private fun greeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when (hour) {
            in 5..11 -> "Доброе утро"
            in 12..17 -> "Добрый день"
            in 18..22 -> "Добрый вечер"
            else -> "Доброй ночи"
        }
        return "$hello! Чем могу помочь?"
    }

    private fun plural(n: Int, one: String, few: String, many: String): String {
        val m100 = n % 100
        val m10 = n % 10
        return when {
            m100 in 11..14 -> many
            m10 == 1 -> one
            m10 in 2..4 -> few
            else -> many
        }
    }

    private fun launch(context: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun audio(context: Context): AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun mediaKey(context: Context, code: Int) {
        try {
            val am = audio(context)
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
            // нет активного плеера — ничего страшного
        }
    }

    // ---------------- телефон ----------------

    private fun battery(context: Context, say: (String) -> Unit): Boolean {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val suffix = if (bm.isCharging) ", телефон на зарядке" else ""
        say("Заряд $level ${plural(level, "процент", "процента", "процентов")}$suffix")
        return true
    }

    private fun setTorch(context: Context, on: Boolean): Boolean {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                false
            } else {
                cm.setTorchMode(id, on)
                torchOn = on
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun volume(context: Context, t: String, say: (String) -> Unit): Boolean {
        val am = audio(context)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        fun setPercent(p: Int) {
            val v = (max * p.coerceIn(0, 100) / 100.0).roundToInt().coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, AudioManager.FLAG_SHOW_UI)
        }

        val percent = Regex("""(\d{1,3})""").find(t.substringAfter("громкост", ""))
            ?.groupValues?.get(1)?.toIntOrNull()

        when {
            percent != null -> {
                setPercent(percent)
                say("Громкость ${percent.coerceIn(0, 100)} процентов")
            }
            has(t, "максим", "на полную", "на всю") -> {
                setPercent(100)
                say("Максимальная громкость")
            }
            has(t, "половин") -> {
                setPercent(50)
                say("Громкость пятьдесят процентов")
            }
            has(t, "без звука", "выключи звук", "отключи звук", "минимум") -> {
                setPercent(0)
                say("")
            }
            has(t, "громче", "увелич", "прибав", "повыше", "добавь") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                say("")
            }
            has(t, "тише", "уменьш", "убав", "пониже") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("")
            }
            has(t, "включи звук") -> {
                setPercent(50)
                say("Звук включён")
            }
            else -> {
                val now = (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100.0 / max).roundToInt()
                say("Громкость $now процентов")
            }
        }
        return true
    }

    private fun playMusic(context: Context, query: String, say: (String) -> Unit): Boolean {
        if (query.isEmpty()) return false
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, query)
        say(if (launch(context, intent)) "Включаю $query" else "Не нашёл музыкальное приложение")
        return true
    }

    // ---------------- таймеры и будильники ----------------

    private fun parseNumber(s: String): Int? {
        val tokens = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        var total = 0
        for (tok in tokens) {
            val v = tok.toIntOrNull() ?: NUM_WORDS[tok] ?: return null
            total += v
        }
        return total
    }

    private fun toSeconds(numText: String, unit: String): Int? {
        val n = if (numText.isBlank()) 1 else (parseNumber(numText) ?: return null)
        val mult = when {
            unit.startsWith("сек") -> 1
            unit.startsWith("мин") -> 60
            unit.startsWith("час") -> 3600
            else -> return null
        }
        return n * mult
    }

    private fun durationText(seconds: Int): String = when {
        seconds % 3600 == 0 -> {
            val h = seconds / 3600
            "$h ${plural(h, "час", "часа", "часов")}"
        }
        seconds % 60 == 0 -> {
            val m = seconds / 60
            "$m ${plural(m, "минуту", "минуты", "минут")}"
        }
        else -> "$seconds ${plural(seconds, "секунду", "секунды", "секунд")}"
    }

    private fun startTimer(
        context: Context,
        seconds: Int,
        label: String,
        phrase: String,
        say: (String) -> Unit
    ): Boolean {
        if (seconds !in 1..86400) {
            say("Могу поставить таймер от одной секунды до суток")
            return true
        }
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        say(if (launch(context, intent)) phrase else "Не получилось поставить таймер")
        return true
    }

    private fun timerSkill(context: Context, t: String, say: (String) -> Unit): Boolean {
        // «напомни через 10 минут позвонить маме», «разбуди через 20 минут»
        val remind = REMIND_RE.find(t)
        if (remind != null) {
            val seconds = toSeconds(remind.groupValues[1], remind.groupValues[2]) ?: return false
            val fallback = if (has(t, "разбуди", "будильник")) "Будильник" else "Напоминание"
            val label = remind.groupValues[3].trim()
                .removePrefix("что ").removePrefix("чтобы ").ifBlank { fallback }
            return startTimer(context, seconds, label, "Напомню через ${durationText(seconds)}", say)
        }

        if (has(t, "таймер", "засеки", "отсчитай")) {
            val half = when {
                t.contains("полчаса") -> 1800
                t.contains("полтора часа") -> 5400
                else -> null
            }
            if (half != null) {
                return startTimer(context, half, "Таймер", "Ставлю таймер на ${durationText(half)}", say)
            }
            val m = TIMER_RE.find(t) ?: return false
            val seconds = toSeconds(m.groupValues[1], m.groupValues[2]) ?: return false
            return startTimer(context, seconds, "Таймер", "Ставлю таймер на ${durationText(seconds)}", say)
        }

        if (has(t, "будильник", "разбуди")) {
            val m = ALARM_RE.find(t)
            if (m == null) {
                say("Скажите время, например: поставь будильник на семь тридцать")
                return true
            }
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifBlank { "0" }.toInt()
            when (m.groupValues[3]) {
                "вечера", "дня" -> if (h < 12) h += 12
                "ночи" -> if (h == 12) h = 0
            }
            if (h !in 0..23 || min !in 0..59) return false
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Джарвис")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            say(
                if (launch(context, intent)) "Будильник на ${String.format(Locale.US, "%d:%02d", h, min)}"
                else "Не получилось поставить будильник"
            )
            return true
        }
        return false
    }

    // ---------------- калькулятор ----------------

    private fun calc(t: String, say: (String) -> Unit): Boolean {
        val m = CALC_RE.find(t) ?: return false
        var e = m.groupValues[1]
        e = e.replace("умножить на", "*").replace("помножить на", "*").replace("умноженное на", "*")
            .replace("разделить на", "/").replace("поделить на", "/").replace("делить на", "/")
            .replace("плюс", "+").replace("минус", "-")
            .replace(" x ", " * ").replace(" х ", " * ").replace("×", "*").replace("÷", "/")
            .replace(',', '.')
        e = e.replace(Regex("\\s+"), " ").trim()
        if (!Regex("""^[0-9.+\-*/() ]+$""").matches(e) || !e.any { it.isDigit() }) return false

        val result = try {
            ExprParser(e).parse()
        } catch (ex: Exception) {
            say("Не смог посчитать")
            return true
        }
        if (result.isNaN() || result.isInfinite()) {
            say("На ноль делить нельзя")
        } else {
            say("Будет ${formatNumber(result)}")
        }
        return true
    }

    private fun formatNumber(v: Double): String =
        if (v == floor(v) && abs(v) < 1e12) {
            v.toLong().toString()
        } else {
            String.format(Locale("ru"), "%.4f", v).trimEnd('0').trimEnd(',')
        }

    private class ExprParser(private val s: String) {
        private var pos = 0

        fun parse(): Double {
            val v = expr()
            skip()
            if (pos != s.length) throw IllegalArgumentException("лишние символы")
            return v
        }

        private fun skip() {
            while (pos < s.length && s[pos] == ' ') pos++
        }

        private fun expr(): Double {
            var v = term()
            while (true) {
                skip()
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                    val op = s[pos++]
                    val r = term()
                    v = if (op == '+') v + r else v - r
                } else {
                    break
                }
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (true) {
                skip()
                if (pos < s.length && (s[pos] == '*' || s[pos] == '/')) {
                    val op = s[pos++]
                    val r = factor()
                    v = if (op == '*') v * r else v / r
                } else {
                    break
                }
            }
            return v
        }

        private fun factor(): Double {
            skip()
            if (pos < s.length && s[pos] == '-') {
                pos++
                return -factor()
            }
            if (pos < s.length && s[pos] == '(') {
                pos++
                val v = expr()
                skip()
                if (pos >= s.length || s[pos] != ')') throw IllegalArgumentException("нет скобки")
                pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("нет числа")
            return s.substring(start, pos).toDouble()
        }
    }

    // ---------------- погода и карты ----------------

    private fun weather(context: Context, t: String, say: (String) -> Unit): Boolean {
        val tomorrow = t.contains("завтра")
        val cleaned = t.replace(Regex("""(?:^|\s)(?:сегодня|завтра|послезавтра|сейчас|на улице|на завтра)(?=\s|$)"""), " ")
            .replace(Regex("\\s+"), " ").trim()
        var city = CITY_RE.find(cleaned)?.groupValues?.get(1)?.trim() ?: ""
        if (city.isBlank()) city = Prefs(context).homeCity
        if (city.isBlank()) {
            say("Скажите город, например: погода в Москве. Или укажите домашний город в настройках.")
            return true
        }
        WeatherClient.fetch(city, tomorrow) { text -> say(text) }
        return true
    }

    private fun navigate(context: Context, destination: String, say: (String) -> Unit): Boolean {
        if (destination.isEmpty()) return false
        val q = Uri.encode(destination)
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q"))
            .setPackage("com.google.android.apps.maps")
        val ok = launch(context, nav) ||
            launch(context, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
        say(if (ok) "Строю маршрут: $destination" else "Не нашёл приложение с картами")
        return true
    }

    private fun showOnMap(context: Context, place: String, say: (String) -> Unit): Boolean {
        if (place.isEmpty()) return false
        val q = Uri.encode(place)
        val ok = launch(context, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
        say(if (ok) "Показываю на карте: $place" else "Не нашёл приложение с картами")
        return true
    }
}
