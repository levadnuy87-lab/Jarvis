package com.example.voicearena

import android.content.Context
import android.net.Uri
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Разбор команд без сервера: приложения, нажатия, таймеры, будильники, фонарик, громкость,
 * музыка, время, дата, заряд, шутки. Цепочки соединяются словами «потом» / «затем».
 */
object LocalParser {

    private val chainSplit =
        Regex("\\s+(?:и\\s+)?(?:потом|затем)\\s+", RegexOption.IGNORE_CASE)

    private val numberWords = mapOf(
        "один" to 1, "одну" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3,
        "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8,
        "девять" to 9, "десять" to 10, "пятнадцать" to 15, "двадцать" to 20,
        "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60
    )

    private val durationRegex = Regex(
        "(?<!\\p{L})(\\d+|" + numberWords.keys.joinToString("|") + ")?\\s*(секунд\\w*|минут\\w*|час\\w*)"
    )

    private val timeRegex = Regex("(\\d{1,2})(?:[:.\\s](\\d{2}))?")

    private val jokes = listOf(
        "Почему программисты любят тёмную тему? Потому что свет привлекает баги.",
        "Я бы рассказал шутку про UDP, но боюсь, что она до вас не дойдёт.",
        "Вчера придумал очень надёжный пароль. Теперь не помню его даже я.",
        "Мой любимый спорт — переводить будильник ещё на пять минут.",
        "Телефон на зарядке похож на кота на солнышке: никуда не торопится."
    )

    fun parse(context: Context, raw: String): List<Step> =
        raw.trim().split(chainSplit).flatMap { parseOne(context, it.trim()) }

    private fun parseOne(context: Context, raw: String): List<Step> {
        val text = raw.trim().trimEnd('.', '!', '?')
        val cmd = text.lowercase()
        if (cmd.isEmpty()) return emptyList()

        fun rest(prefix: String): String = text.substring(prefix.length).trim()
        fun one(action: String, value: String): List<Step> = listOf(Step(action, value))
        fun say(message: String): List<Step> = one("say", message)

        // 1. Команды с глаголом в начале
        when {
            cmd.startsWith("открой ссылку ") -> return one("url", rest("открой ссылку "))
            cmd.startsWith("открой сайт ") -> return one("url", rest("открой сайт "))
            cmd.startsWith("открой ") -> return one("open_app", rest("открой "))
            cmd.startsWith("запусти ") -> return one("open_app", rest("запусти "))
            cmd.startsWith("нажми ") -> return one("click", rest("нажми "))
            cmd.startsWith("нажать ") -> return one("click", rest("нажать "))
            cmd.startsWith("напиши ") -> return one("type", rest("напиши "))
            cmd.startsWith("введи ") -> return one("type", rest("введи "))
            cmd.startsWith("позвони ") -> return one("dial", rest("позвони "))
            cmd.startsWith("набери ") -> return one("dial", rest("набери "))
            cmd.startsWith("найди ") ->
                return one("url", "https://www.google.com/search?q=" + Uri.encode(rest("найди ")))
        }

        // 2. Таймер и будильник
        if (cmd.contains("таймер")) {
            val seconds = parseDurationSeconds(cmd)
            if (seconds <= 0) return say("На сколько поставить таймер?")
            return say("Ставлю таймер на ${describeSeconds(seconds)}") + Step("timer", seconds.toString())
        }
        if (cmd.contains("будильник") || cmd.startsWith("разбуди")) {
            val time = parseAlarmTime(cmd)
                ?: return say("Назовите время цифрами, например: будильник на 7 30")
            return say("Ставлю будильник на $time") + Step("alarm", time)
        }

        // 3. Телефон: фонарик, звук, музыка, экран
        if (cmd.contains("фонарик") || cmd.contains("фонарь")) {
            val off = cmd.contains("выключ") || cmd.contains("погаси")
            return one("flashlight", if (off) "off" else "on")
        }
        when {
            cmd.contains("громче") || cmd.contains("прибавь") -> return one("volume", "up")
            cmd.contains("тише") || cmd.contains("убавь") -> return one("volume", "down")
            cmd.contains("без звука") || cmd.contains("выключи звук") -> return one("volume", "mute")
            cmd.contains("громкость") -> {
                if (cmd.contains("максимум")) return one("volume", "max")
                val percent = Regex("\\d+").find(cmd)?.value
                return if (percent != null) one("volume", percent) else say("На сколько поставить громкость?")
            }
        }
        when {
            cmd == "пауза" || cmd.contains("на паузу") || cmd.contains("останови музыку") ->
                return one("media", "pause")
            cmd == "играй" || cmd.contains("продолжи") || cmd.contains("воспроизведи") ->
                return one("media", "play")
            cmd.contains("следующ") || cmd == "дальше" -> return one("media", "next")
            cmd.contains("предыдущ") || cmd.contains("прошлый трек") -> return one("media", "prev")
            cmd.contains("скриншот") || cmd.contains("снимок экрана") -> return one("global", "скриншот")
            cmd.contains("заблокируй") -> return one("global", "блокировка")
            cmd == "домой" || cmd == "на главный экран" -> return one("global", "домой")
            cmd == "назад" -> return one("global", "назад")
            cmd == "недавние" || cmd == "последние приложения" -> return one("global", "недавние")
            cmd == "уведомления" || cmd == "шторка" -> return one("global", "уведомления")
            cmd == "быстрые настройки" -> return one("global", "быстрые настройки")
        }

        // 4. Вопросы про устройство и немного общения
        val ru = Locale("ru")
        when {
            cmd.contains("который час") || cmd.contains("сколько времени") || cmd == "время" ->
                return say("Сейчас " + SimpleDateFormat("H:mm", ru).format(Date()))
            cmd.contains("какое число") || cmd.contains("какое сегодня") ||
                cmd.contains("какой сегодня день") || cmd.contains("какая сегодня дата") || cmd == "дата" ->
                return say("Сегодня " + SimpleDateFormat("d MMMM, EEEE", ru).format(Date()))
            cmd.contains("заряд") || cmd.contains("батаре") -> {
                val manager = context.getSystemService(BatteryManager::class.java)
                val level = manager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
                return if (level in 0..100) say("Заряд батареи $level процентов") else say("Не удалось узнать заряд")
            }
            cmd.contains("погод") ->
                return say("Открываю прогноз погоды") +
                    Step("url", "https://www.google.com/search?q=" + Uri.encode("погода"))
            cmd.contains("шутк") || cmd.contains("анекдот") -> return say(jokes.random())
            cmd == "привет" || cmd == "здравствуй" || cmd == "здравствуйте" ->
                return say("Здравствуйте! Чем могу помочь?")
            cmd.contains("как дела") -> return say("Отлично, работаю без выходных. А у вас?")
            cmd.contains("спасибо") -> return say("Всегда пожалуйста")
            cmd.contains("кто ты") || cmd.contains("как тебя зовут") ->
                return say("Я Джарвис, голосовой помощник на вашем телефоне")
        }

        if (cmd.startsWith("включи ")) return one("open_app", rest("включи "))
        return emptyList()
    }

    private fun parseDurationSeconds(cmd: String): Int {
        if (cmd.contains("полчаса")) return 1800
        var total = 0
        for (match in durationRegex.findAll(cmd)) {
            val numText = match.groupValues[1]
            val n = if (numText.isEmpty()) 1 else (numText.toIntOrNull() ?: numberWords[numText] ?: 1)
            val unit = match.groupValues[2]
            total += when {
                unit.startsWith("сек") -> n
                unit.startsWith("мин") -> n * 60
                else -> n * 3600
            }
        }
        return total
    }

    private fun describeSeconds(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h ч")
        if (m > 0) parts.add("$m мин")
        if (s > 0) parts.add("$s сек")
        return parts.joinToString(" ")
    }

    /** Возвращает «ч:мм» или null, если время не распознано. */
    private fun parseAlarmTime(cmd: String): String? {
        val match = timeRegex.find(cmd) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        if ((cmd.contains("вечера") || cmd.contains("дня")) && hour in 1..11) hour += 12
        if (hour !in 0..23 || minute !in 0..59) return null
        return "%d:%02d".format(hour, minute)
    }
}
