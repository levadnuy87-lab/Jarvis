package com.example.voicearena

import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Отправляет распознанный текст на ваш сервер и получает список шагов. */
object ServerClient {

    data class Reply(val say: String, val steps: List<Step>)

    interface ServerCallback {
        fun onSuccess(reply: Reply)
        fun onFailure(message: String)
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .build()

    private fun normalize(base: String): String? {
        val trimmed = base.trim().trimEnd('/')
        if (trimmed.isEmpty()) return null
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else {
            "http://$trimmed"
        }
    }

    fun send(baseUrl: String, token: String, text: String, callback: ServerCallback) {
        val url = normalize(baseUrl)?.let { "$it/execute".toHttpUrlOrNull() }
        if (url == null) {
            callback.onFailure("Неверный адрес сервера")
            return
        }

        val request = try {
            val body = JSONObject().put("text", text).toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())
            val builder = Request.Builder().url(url).post(body)
            if (token.isNotBlank()) {
                builder.header("Authorization", "Bearer ${token.trim()}")
            }
            builder.build()
        } catch (e: IllegalArgumentException) {
            callback.onFailure("Неверный токен или адрес сервера")
            return
        }

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.onFailure("Сервер недоступен: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    if (r.code == 401) {
                        callback.onFailure("Сервер: неверный токен")
                        return
                    }
                    if (!r.isSuccessful) {
                        callback.onFailure("Ошибка сервера: ${r.code}")
                        return
                    }
                    try {
                        val json = JSONObject(r.body?.string() ?: "{}")
                        val array = json.optJSONArray("steps")
                        val steps = ArrayList<Step>()
                        if (array != null) {
                            for (i in 0 until array.length()) {
                                val item = array.optJSONObject(i) ?: continue
                                val action = item.optString("action", "")
                                if (action.isNotBlank()) {
                                    steps.add(Step(action, item.optString("value", "")))
                                }
                            }
                        }
                        callback.onSuccess(Reply(json.optString("say", ""), steps))
                    } catch (e: Exception) {
                        callback.onFailure("Не разобрал ответ сервера")
                    }
                }
            }
        })
    }
}
