package com.example.voicearena

/** Поиск слова активации «Джарвис» в распознанной фразе. */
object WakeWord {

    // Распознаватель может написать слово по-разному, поэтому несколько вариантов.
    private val pattern = Regex(
        "(?:^|[^\\p{L}])(джарвис|джарвиз|джервис|жарвис|дарвис|jarvis)(?=[^\\p{L}]|$)"
    )

    /**
     * null — слова активации в фразе нет.
     * Иначе возвращает то, что сказано после него (может быть пустой строкой).
     */
    fun extractCommand(text: String): String? {
        val lower = text.lowercase()
        val match = pattern.find(lower) ?: return null
        val source = if (lower.length == text.length) text else lower
        return source.substring(match.range.last + 1).trim {
            it.isWhitespace() || it == ',' || it == '.' || it == '!' || it == '-' || it == ':'
        }
    }
}
