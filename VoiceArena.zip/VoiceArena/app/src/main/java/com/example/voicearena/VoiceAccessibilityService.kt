package com.example.voicearena

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.view.KeyEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * «Руки» ассистента: открывает приложения, нажимает кнопки, вводит текст.
 * Ещё рисует плавающую кнопку 🎙 поверх любых экранов.
 */
class VoiceAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: VoiceAccessibilityService? = null
            private set

        private val COLOR_IDLE = 0xFF2962FF.toInt()
        private val COLOR_LISTENING = 0xFFD50000.toInt()

        // Как люди говорят -> как приложение может называться на телефоне.
        private val APP_ALIASES: Map<String, List<String>> = mapOf(
            "телеграм" to listOf("telegram"),
            "телега" to listOf("telegram"),
            "тг" to listOf("telegram"),
            "ютуб" to listOf("youtube"),
            "ютюб" to listOf("youtube"),
            "ватсап" to listOf("whatsapp"),
            "вацап" to listOf("whatsapp"),
            "вотсап" to listOf("whatsapp"),
            "инстаграм" to listOf("instagram"),
            "инсту" to listOf("instagram"),
            "инста" to listOf("instagram"),
            "почта" to listOf("gmail", "почта"),
            "почту" to listOf("gmail", "почта"),
            "гмейл" to listOf("gmail"),
            "карты" to listOf("maps", "карты"),
            "навигатор" to listOf("maps", "карты", "navigator"),
            "хром" to listOf("chrome"),
            "браузер" to listOf("chrome", "браузер", "browser"),
            "камера" to listOf("camera", "камера"),
            "камеру" to listOf("camera", "камера"),
            "калькулятор" to listOf("calculator", "калькулятор"),
            "часы" to listOf("clock", "часы"),
            "будильник" to listOf("clock", "часы"),
            "настройки" to listOf("settings", "настройки"),
            "музыка" to listOf("spotify", "music", "музыка"),
            "музыку" to listOf("spotify", "music", "музыка"),
            "спотифай" to listOf("spotify"),
            "галерея" to listOf("gallery", "photos", "галерея", "фото"),
            "фото" to listOf("photos", "gallery", "фото", "галерея"),
            "сообщения" to listOf("messages", "сообщения"),
            "контакты" to listOf("contacts", "контакты"),
            "телефон" to listOf("phone", "телефон")
        )
    }

    private val main = Handler(Looper.getMainLooper())

    private var overlay: View? = null
    private var overlayBg: GradientDrawable? = null
    private var voice: VoiceInput? = null

    // ---------- жизненный цикл ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Speaker.init(this)
        showOverlay()
        toast("Voice Arena: служба активна")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        voice?.destroy()
        voice = null
        instance = null
    }

    // ---------- выполнение команд ----------

    /** Выполняет шаги по очереди; между шагами пауза, чтобы экран успел перерисоваться. */
    fun runSteps(steps: List<Step>) {
        var delay = 0L
        for (step in steps) {
            main.postDelayed({ execute(step) }, delay)
            delay += when (step.action) {
                "open_app", "url", "dial" -> 2500L
                "click" -> 1200L
                else -> 800L
            }
        }
    }

    private fun execute(step: Step) {
        when (step.action) {
            "open_app" -> openApp(step.value)
            "click" -> clickByText(step.value, 3)
            "type" -> typeText(step.value, 3)
            "dial" -> dial(step.value)
            "url" -> openUrl(step.value)
            "global" -> globalAction(step.value)
            "say" -> reply(step.value)
            "timer" -> setTimer(step.value)
            "alarm" -> setAlarm(step.value)
            "flashlight" -> setTorch(step.value.trim().lowercase() != "off")
            "volume" -> changeVolume(step.value.trim().lowercase())
            "media" -> mediaKey(step.value.trim().lowercase())
            else -> toast("Неизвестная команда: ${step.action}")
        }
    }

    private fun globalAction(value: String) {
        val ok = when (value.trim().lowercase()) {
            "домой", "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "назад", "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "недавние", "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "уведомления", "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "быстрые настройки", "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "скриншот", "screenshot" ->
                if (Build.VERSION.SDK_INT >= 28) {
                    performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                } else {
                    toast("Скриншот работает на Android 9 и новее")
                    true
                }
            "блокировка", "lock" ->
                if (Build.VERSION.SDK_INT >= 28) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                } else {
                    toast("Блокировка работает на Android 9 и новее")
                    true
                }
            else -> {
                toast("Неизвестное действие: $value")
                true
            }
        }
        if (!ok) toast("Не удалось выполнить: $value")
    }

    private fun openApp(name: String) {
        val query = name.trim().lowercase()
        if (query.isEmpty()) {
            toast("Не услышал название приложения")
            return
        }
        val needles = listOf(query) + (APP_ALIASES[query] ?: emptyList())

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(launcher, 0)
        val labeled = apps.map { it to it.loadLabel(pm).toString().lowercase() }

        val match = labeled.firstOrNull { (_, label) -> needles.any { label == it } }
            ?: labeled.firstOrNull { (_, label) -> needles.any { label.contains(it) } }

        if (match == null) {
            reply("Не нашёл приложение «$name»")
            return
        }

        val packageName = match.first.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(packageName)
        if (intent == null) {
            toast("Не удалось запустить «$name»")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun clickByText(text: String, attemptsLeft: Int) {
        val root = rootInActiveWindow
        val node = if (root != null) findNodeByText(root, text) else null

        if (node == null) {
            if (attemptsLeft > 1) {
                main.postDelayed({ clickByText(text, attemptsLeft - 1) }, 800)
            } else {
                toast("Не нашёл «$text»")
            }
            return
        }

        val target = findClickableParent(node) ?: node
        if (!target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            toast("Не удалось нажать «$text»")
        }
    }

    private fun typeText(text: String, attemptsLeft: Int) {
        val root = rootInActiveWindow
        val field = if (root != null) {
            root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
        } else {
            null
        }

        if (field == null) {
            if (attemptsLeft > 1) {
                main.postDelayed({ typeText(text, attemptsLeft - 1) }, 800)
            } else {
                toast("Нет поля ввода")
            }
            return
        }

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            toast("Не удалось ввести текст")
        }
    }

    private fun dial(target: String) {
        var number = target.filter { it.isDigit() || it == '+' }
        if (target.any { it.isLetter() }) {
            // в команде имя, а не номер: «позвони маме»
            number = findContactNumber(target) ?: return
        }
        if (number.isEmpty()) {
            reply("Не разобрал номер")
            return
        }
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    /** Ищет контакт по имени; для «маме» / «Ивану» отбрасывает окончание. */
    private fun findContactNumber(query: String): String? {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
            reply("Разрешите доступ к контактам в приложении Voice Arena")
            return null
        }
        val q = query.trim().lowercase()
        val candidates = listOf(q, q.dropLast(1), q.dropLast(2)).filter { it.length >= 3 }.distinct()

        val rows = ArrayList<Pair<String, String>>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null,
            null,
            null
        )
        cursor?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0)
                val number = c.getString(1)
                if (name != null && number != null) rows.add(name.lowercase() to number)
            }
        }

        for (candidate in candidates) {
            val found = rows.firstOrNull { it.first.contains(candidate) }
            if (found != null) return found.second
        }
        reply("Не нашёл контакт «$query»")
        return null
    }

    private fun openUrl(url: String) {
        val fixed = if (url.startsWith("http")) url else "https://$url"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fixed))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    // ---------- умения телефона ----------

    /** Показывает текст и озвучивает его. */
    private fun reply(text: String) {
        toast(text)
        Speaker.speak(this, text)
    }

    private fun setTimer(seconds: String) {
        val total = seconds.trim().toIntOrNull()
        if (total == null || total <= 0) {
            reply("Не понял, на сколько таймер")
            return
        }
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, total)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Джарвис")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            reply("Не нашёл приложение «Часы»")
        }
    }

    private fun setAlarm(time: String) {
        val parts = time.trim().split(':')
        val hour = parts.getOrNull(0)?.toIntOrNull()
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        if (hour == null || hour !in 0..23 || minute !in 0..59) {
            reply("Не понял время будильника")
            return
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Джарвис")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            reply("Не нашёл приложение «Часы»")
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val manager = getSystemService(CameraManager::class.java)
            val id = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                reply("На этом телефоне нет фонарика")
                return
            }
            manager.setTorchMode(id, on)
        } catch (e: Exception) {
            toast("Не удалось управлять фонариком")
        }
    }

    private fun changeVolume(value: String) {
        val audio = getSystemService(AudioManager::class.java)
        val stream = AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(stream)
        when (value) {
            "up" -> audio.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "down" -> audio.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "mute" -> audio.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            "max" -> audio.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
            else -> {
                val percent = value.toIntOrNull()
                if (percent == null) {
                    toast("Не понял громкость: $value")
                } else {
                    val level = (max * percent / 100).coerceIn(0, max)
                    audio.setStreamVolume(stream, level, AudioManager.FLAG_SHOW_UI)
                }
            }
        }
    }

    private fun mediaKey(value: String) {
        val code = when (value) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> {
                toast("Неизвестная команда плеера: $value")
                return
            }
        }
        val audio = getSystemService(AudioManager::class.java)
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---------- поиск элементов на экране ----------

    private fun findNodeByText(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val needle = text.trim().lowercase()
        if (needle.isEmpty()) return null
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)

        while (stack.isNotEmpty()) {
            val node = stack.removeAt(stack.lastIndex)
            val nodeText = node.text?.toString()?.lowercase()
            val desc = node.contentDescription?.toString()?.lowercase()

            if (nodeText?.contains(needle) == true || desc?.contains(needle) == true) {
                return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.add(it) }
            }
        }
        return null
    }

    private fun findClickableParent(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) return current
            current = current.parent
        }
        return null
    }

    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val stack = ArrayList<AccessibilityNodeInfo>()
        stack.add(root)

        while (stack.isNotEmpty()) {
            val node = stack.removeAt(stack.lastIndex)
            if (node.isEditable) return node
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.add(it) }
            }
        }
        return null
    }

    // ---------- плавающая кнопка 🎙 ----------

    val isOverlayVisible: Boolean
        get() = overlay != null

    fun toggleOverlay() {
        if (overlay == null) showOverlay() else removeOverlay()
    }

    private fun showOverlay() {
        if (overlay != null) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val size = (56 * metrics.density).toInt()

        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(COLOR_IDLE)
        }
        val view = TextView(this).apply {
            text = "🎙"
            textSize = 24f
            gravity = Gravity.CENTER
            background = bg
            alpha = 0.9f
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = metrics.widthPixels - size - (8 * metrics.density).toInt()
            y = metrics.heightPixels / 2
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop

        // Кнопку можно перетащить; короткое касание — «слушать».
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var downX = 0f
            private var downY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        downX = event.rawX
                        downY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt()
                        val dy = (event.rawY - downY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            wm.updateViewLayout(v, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) onMicTapped()
                        return true
                    }
                }
                return false
            }
        })

        try {
            wm.addView(view, params)
            overlay = view
            overlayBg = bg
        } catch (e: Exception) {
            toast("Не удалось показать плавающую кнопку")
        }
    }

    private fun removeOverlay() {
        val view = overlay ?: return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            wm.removeView(view)
        } catch (e: Exception) {
            // окно уже удалено — ничего страшного
        }
        overlay = null
        overlayBg = null
    }

    private fun setOverlayListening(listening: Boolean) {
        overlayBg?.setColor(if (listening) COLOR_LISTENING else COLOR_IDLE)
    }

    private fun onMicTapped() {
        // Если включена активация «Джарвис», кнопка просто «будит» её.
        val wake = WakeWordService.instance
        if (wake != null) {
            wake.activateNow()
            return
        }

        Speaker.stop()
        var input = voice
        if (input == null) {
            input = VoiceInput(this) { msg -> toast(msg) }
            input.onListening = { listening -> setOverlayListening(listening) }
            voice = input
        }
        if (!input.hasPermission()) {
            toast("Откройте Voice Arena и разрешите микрофон")
            return
        }
        input.start()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
