package com.example.voicearena

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Ждёт слово «Джарвис» и слушает команду.
 *
 * Два движка слова активации:
 *  • Picovoice Porcupine — работает на телефоне, без интернета, мало тратит батарею
 *    (нужен бесплатный ключ Picovoice в настройках);
 *  • распознавание речи Google — запасной вариант, ловит слово в потоке фраз.
 *
 * Как говорить: «Джарвис, открой ютуб» или «Джарвис» → «Слушаю» → команда.
 * После ответа ещё ~7 секунд можно уточнять без слова «Джарвис».
 * Пока Джарвис говорит, микрофон не слушает (иначе он слышал бы сам себя).
 */
class WakeWordService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voicearena.STOP_WAKE"
        private const val CHANNEL_ID = "wake_word"
        private const val NOTIFICATION_ID = 42
        private const val IDLE_TEXT = "Скажите «Джарвис» и команду"
        private const val FOLLOW_UP_MS = 7000L

        private val STOP_WORDS = setOf(
            "стоп", "хватит", "отмена", "замолчи", "молчи", "тихо", "помолчи", "достаточно"
        )

        @Volatile
        var instance: WakeWordService? = null
            private set

        val isRunning: Boolean
            get() = instance != null
    }

    private enum class Mode { WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var porcupine: PorcupineManager? = null
    private var porcupineRunning = false
    private var mode = Mode.WAKE
    private var quiet = false
    private var stopped = false
    private var started = false
    private var speaking = false
    private var followUpUntil = 0L
    private var wakeLock: PowerManager.WakeLock? = null

    /** true, если слово «Джарвис» ловит Picovoice (иначе — Google). */
    val enginePorcupine: Boolean
        get() = porcupine != null

    private val startRunnable = Runnable { startRecognizer() }
    private val resumeRunnable = Runnable { resumeIdle() }

    // Пока Джарвис говорит — не слушаем; замолчал — через мгновение слушаем снова.
    private val speakingListener: (Boolean) -> Unit = { isSpeaking ->
        speaking = isSpeaking
        if (isSpeaking) {
            main.removeCallbacks(startRunnable)
            main.removeCallbacks(resumeRunnable)
            recognizer?.destroy()
            recognizer = null
            stopPorcupine()
        } else if (!stopped) {
            followUpUntil = SystemClock.elapsedRealtime() + FOLLOW_UP_MS
            if (mode == Mode.COMMAND) listenSoon(350) else main.postDelayed(resumeRunnable, 350)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        createChannel()
        try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(IDLE_TEXT),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            toast("Не удалось запустить прослушивание: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        instance = this
        if (!started) {
            started = true
            stopped = false
            mode = Mode.WAKE
            Speaker.init(this)
            Speaker.onSpeakingChanged = speakingListener
            acquireWakeLock()
            setupPorcupine()
            resumeIdle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopped = true
        started = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        stopPorcupine()
        try {
            porcupine?.delete()
        } catch (e: Exception) {
            // уже освобождён
        }
        porcupine = null
        if (Speaker.onSpeakingChanged === speakingListener) {
            Speaker.stop()
            Speaker.onSpeakingChanged = null
        }
        releaseWakeLock()
        instance = null
        super.onDestroy()
    }

    /** Плавающая кнопка или кнопка в приложении: прервать речь и сразу ждать команду. */
    fun activateNow() {
        if (stopped) return
        Speaker.stop()
        main.removeCallbacks(startRunnable)
        main.removeCallbacks(resumeRunnable)
        recognizer?.destroy()
        recognizer = null
        enterCommandMode(quietMode = false, announce = true)
    }

    // ---------- Picovoice ----------

    private fun setupPorcupine() {
        val key = Prefs(this).picoKey
        if (key.isBlank()) return
        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.65f)
                .build(applicationContext, PorcupineManagerCallback { _ ->
                    main.post { onWakeDetected() }
                })
        } catch (e: Exception) {
            porcupine = null
            toast("Picovoice не запустился (${e.message}). Слушаю через Google.")
        }
    }

    private fun startPorcupine() {
        val p = porcupine ?: return
        if (porcupineRunning || stopped || speaking) return
        try {
            p.start()
            porcupineRunning = true
        } catch (e: Exception) {
            toast("Picovoice остановился (${e.message}). Слушаю через Google.")
            try {
                p.delete()
            } catch (ignored: Exception) {
                // не критично
            }
            porcupine = null
            porcupineRunning = false
            listenSoon(300)
        }
    }

    private fun stopPorcupine() {
        val p = porcupine ?: return
        if (!porcupineRunning) return
        try {
            p.stop()
        } catch (e: Exception) {
            // не критично
        }
        porcupineRunning = false
    }

    private fun onWakeDetected() {
        if (stopped || mode != Mode.WAKE || speaking) return
        stopPorcupine()
        enterCommandMode(quietMode = false, announce = true)
    }

    // ---------- состояния ----------

    /** Вернуться к ожиданию слова «Джарвис» (или к окну уточнений). */
    private fun resumeIdle() {
        if (stopped || speaking || mode == Mode.COMMAND) return
        mode = Mode.WAKE
        quiet = false
        if (porcupine != null) {
            if (SystemClock.elapsedRealtime() < followUpUntil) {
                enterCommandMode(quietMode = true, announce = false)
            } else {
                updateNotification(IDLE_TEXT)
                startPorcupine()
            }
        } else {
            listenSoon(300)
        }
    }

    private fun enterCommandMode(quietMode: Boolean, announce: Boolean) {
        mode = Mode.COMMAND
        quiet = quietMode
        stopPorcupine()
        if (!quietMode) {
            updateNotification("Слушаю команду…")
            if (announce) {
                if (Prefs(this).voiceReplies) Speaker.speak(this, "Слушаю") else beep()
            }
        }
        listenSoon(150)
    }

    // ---------- распознавание речи ----------

    private fun listenSoon(delayMs: Long) {
        main.removeCallbacks(startRunnable)
        main.postDelayed(startRunnable, delayMs)
    }

    private fun startRecognizer() {
        if (stopped || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Нет службы распознавания речи (нужно приложение Google)")
            stopSelf()
            return
        }

        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // несколько вариантов распознавания — «Джарвис» ловится надёжнее
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            val list = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()
            handleResults(list)
        }

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                toast("Нет доступа к микрофону")
                stopSelf()
                return
            }

            if (mode == Mode.COMMAND) {
                val wasQuiet = quiet
                mode = Mode.WAKE
                quiet = false
                followUpUntil = 0L
                updateNotification(IDLE_TEXT)
                if (!wasQuiet) toast("Не расслышал команду")
                if (porcupine != null) {
                    main.removeCallbacks(resumeRunnable)
                    main.postDelayed(resumeRunnable, 200)
                    return
                }
            } else if (porcupine != null) {
                return
            }

            val delay = when (error) {
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> 1500L
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> 3000L
                else -> 300L
            }
            listenSoon(delay)
        }
    }

    private fun handleResults(list: List<String>) {
        if (list.isEmpty()) {
            if (mode == Mode.COMMAND) {
                mode = Mode.WAKE
                quiet = false
                followUpUntil = 0L
            }
            if (porcupine != null) {
                main.removeCallbacks(resumeRunnable)
                main.postDelayed(resumeRunnable, 200)
            } else {
                listenSoon(300)
            }
            return
        }

        when (mode) {
            Mode.WAKE -> {
                // null — слова «Джарвис» нет ни в одном варианте; "" — сказали только его
                val command = list.firstNotNullOfOrNull { WakeWord.extractCommand(it) }
                when {
                    command == null -> {
                        if (SystemClock.elapsedRealtime() < followUpUntil) {
                            handleCommandText(list.first(), true)
                        } else {
                            listenSoon(200)
                        }
                    }
                    command.isBlank() -> enterCommandMode(quietMode = false, announce = true)
                    else -> handleCommandText(command, false)
                }
            }
            Mode.COMMAND -> {
                val wasQuiet = quiet
                mode = Mode.WAKE
                quiet = false
                val heard = list.first()
                val cleaned = WakeWord.extractCommand(heard)
                handleCommandText(if (cleaned.isNullOrBlank()) heard else cleaned, wasQuiet)
            }
        }
    }

    private fun handleCommandText(text: String, quietReply: Boolean) {
        val normalized = text.lowercase().trim().trim('.', '!', ',', '?')
        if (normalized in STOP_WORDS) {
            Speaker.stop()
            followUpUntil = 0L
            updateNotification(IDLE_TEXT)
            main.removeCallbacks(resumeRunnable)
            main.postDelayed(resumeRunnable, 300)
            return
        }
        runCommand(text, quietReply)
    }

    private fun runCommand(text: String, quietReply: Boolean) {
        followUpUntil = SystemClock.elapsedRealtime() + FOLLOW_UP_MS
        CommandRunner.handle(
            this,
            text,
            onStatus = { msg ->
                updateNotification(msg.replace('\n', ' '))
                toast(msg)
            },
            speakFailure = !quietReply
        )
        main.postDelayed({
            if (mode == Mode.WAKE) updateNotification(IDLE_TEXT)
        }, 6000)
        main.removeCallbacks(resumeRunnable)
        main.postDelayed(resumeRunnable, 1200)
    }

    // ---------- уведомление, звук, питание ----------

    private fun acquireWakeLock() {
        if (!Prefs(this).speakerMode) return
        val pm = getSystemService(PowerManager::class.java)
        val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voicearena:wake")
        lock.setReferenceCounted(false)
        lock.acquire()
        wakeLock = lock
    }

    private fun releaseWakeLock() {
        val lock = wakeLock
        if (lock != null && lock.isHeld) lock.release()
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Режим «Джарвис»",
            NotificationManager.IMPORTANCE_LOW
        )
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP }
        val stop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Джарвис")
            .setContentText(text)
            .setContentIntent(openApp)
            .addAction(0, "Выключить", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun beep() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            main.postDelayed({ tone.release() }, 500)
        } catch (e: Exception) {
            // звук не критичен
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
