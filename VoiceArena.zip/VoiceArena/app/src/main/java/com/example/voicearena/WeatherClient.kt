package com.example.voicearena

import android.os.Handler
import android.os.Looper
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Погода через бесплатный Open-Meteo (ключ не нужен). */
object WeatherClient {

    private val main = Handler(Looper.getMainLooper())

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private class Place(val name: String, val lat: Double, val lon: Double)

    /** Результат (готовая фраза) приходит в главном потоке. */
    fun fetch(city: String, tomorrow: Boolean, callback: (String) -> Unit) {
        Thread {
            val text = try {
                load(city, tomorrow)
            } catch (e: Exception) {
                "Не получилось узнать погоду. Проверьте интернет."
            }
            main.post { callback(text) }
        }.start()
    }

    private fun getJson(url: String): JSONObject? {
        val request = Request.Builder().url(url).build()
        return client.newCall(request).execute().use { r ->
            if (!r.isSuccessful) null else r.body?.string()?.let { JSONObject(it) }
        }
    }

    private fun geocode(name: String): Place? {
        // «Москве» -> «Москв» -> «Мос»: геокодер ищет по началу названия.
        var candidate = name.trim()
        repeat(4) {
            if (candidate.length >= 3) {
                val url = "https://geocoding-api.open-meteo.com/v1/search".toHttpUrl().newBuilder()
                    .addQueryParameter("name", candidate)
                    .addQueryParameter("count", "1")
                    .addQueryParameter("language", "ru")
                    .addQueryParameter("format", "json")
                    .build()
                val results = getJson(url.toString())?.optJSONArray("results")
                if (results != null && results.length() > 0) {
                    val r = results.getJSONObject(0)
                    return Place(r.optString("name", candidate), r.getDouble("latitude"), r.getDouble("longitude"))
                }
            }
            candidate = candidate.dropLast(1)
        }
        return null
    }

    private fun load(city: String, tomorrow: Boolean): String {
        val place = geocode(city) ?: return "Не нашёл город «$city»"
        val url = "https://api.open-meteo.com/v1/forecast".toHttpUrl().newBuilder()
            .addQueryParameter("latitude", place.lat.toString())
            .addQueryParameter("longitude", place.lon.toString())
            .addQueryParameter("current", "temperature_2m,apparent_temperature,weather_code,wind_speed_10m")
            .addQueryParameter(
                "daily",
                "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
            )
            .addQueryParameter("forecast_days", "2")
            .addQueryParameter("timezone", "auto")
            .build()
        val json = getJson(url.toString()) ?: return "Сервис погоды не отвечает"

        if (tomorrow) {
            val d = json.getJSONObject("daily")
            val code = d.getJSONArray("weather_code").getInt(1)
            val max = d.getJSONArray("temperature_2m_max").getDouble(1)
            val min = d.getJSONArray("temperature_2m_min").getDouble(1)
            val rain = d.optJSONArray("precipitation_probability_max")?.optInt(1, -1) ?: -1
            val sb = StringBuilder("${place.name}, завтра: от ${temp(min)} до ${temp(max)}, ${describe(code)}")
            if (rain >= 0) sb.append(", вероятность осадков $rain процентов")
            return sb.toString()
        }

        val c = json.getJSONObject("current")
        val t = c.getDouble("temperature_2m")
        val feels = c.optDouble("apparent_temperature", t)
        val wind = Math.round(c.optDouble("wind_speed_10m", 0.0)).toInt()
        val code = c.getInt("weather_code")
        return "${place.name}, сейчас ${temp(t)}, ${describe(code)}, " +
            "ощущается как ${temp(feels)}, ветер $wind километров в час"
    }

    private fun temp(v: Double): String {
        val n = Math.round(v).toInt()
        return when {
            n > 0 -> "плюс $n"
            n < 0 -> "минус ${-n}"
            else -> "ноль градусов"
        }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "ясно"
        1 -> "преимущественно ясно"
        2 -> "переменная облачность"
        3 -> "пасмурно"
        45, 48 -> "туман"
        51, 53, 55 -> "морось"
        56, 57 -> "ледяная морось"
        61 -> "небольшой дождь"
        63 -> "дождь"
        65 -> "сильный дождь"
        66, 67 -> "ледяной дождь"
        71 -> "небольшой снег"
        73 -> "снег"
        75 -> "сильный снег"
        77 -> "снежная крупа"
        80, 81, 82 -> "ливень"
        85, 86 -> "снегопад"
        95 -> "гроза"
        96, 99 -> "гроза с градом"
        else -> "без подробностей"
    }
}
