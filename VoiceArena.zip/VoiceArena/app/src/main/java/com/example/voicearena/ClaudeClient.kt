package com.example.voicearena

import android.content.Context
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * «Мозг» Джарвиса: отправляет фразу в Claude API прямо с телефона.
 * Claude отвечает текстом (его озвучит колонка) и/или вызывает инструмент phone_commands.
 */
object ClaudeClient {

    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val API_VERSION = "2023-06-01"

    /** Быстрая и недорогая модель. Её можно заменить на claude-sonnet-5-5. */
    const val MODEL = "claude-haiku-5-5"

    private val ACTIONS = setOf("open_app", "click", "type", "global", "dial", "url")
    private val GLOBALS = setOf(
        "домой", "назад", "недавние", "уведомления", "быстрые настройки", "блокировка", "скриншот"
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .callTimeout(50, TimeUnit.SECONDS)
        .build()

    /** Короткая память разговора: пары (роль, текст). */
    private val history = ArrayList<Pair<String, String>>()

    private const val TOOL_JSON = """
{
  "name": "phone_commands",
  "description": "Выполнить действия на телефоне. Вызывай ТОЛЬКО когда пользователь просит что-то сделать на телефоне. В say — короткое подтверждение.",
  "input_schema": {
    "type": "object",
    "properties": {
      "say": {"type": "string", "description": "Короткая фраза-подтверждение по-русски, до 80 символов"},
      "steps": {
        "type": "array",
        "maxItems": 6,
        "items": {
          "type": "object",
          "properties": {
            "action": {"type": "string", "enum": ["open_app", "click", "type", "global", "dial", "url"]},
            "value": {"type": "string"}
          },
          "required": ["action", "value"]
        }
      }
    },
    "required": ["say", "steps"]
  }
}
"""

    private fun systemPrompt(prefs: Prefs): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val notes = prefs.notes()
        val sb = StringBuilder()
        sb.append("Ты — Джарвис, голосовой помощник на Android-телефоне, как умная колонка. ")
        sb.append("Сейчас: $now. Пользователь говорит по-русски.\n\n")
        sb.append("ВАЖНО: твой текст будет ОЗВУЧЕН голосом. Отвечай коротко (1–3 предложения), ")
        sb.append("разговорно, без markdown, списков, эмодзи и ссылок. Обращайся на «вы». ")
        sb.append("Если нужно задать уточняющий вопрос, заканчивай ответ вопросительным знаком; ")
        sb.append("иначе вопросов не задавай.\n\n")
        sb.append("Если нужно что-то СДЕЛАТЬ на телефоне — вызови инструмент phone_commands. ")
        sb.append("Шаги: open_app (название приложения как на телефоне), click (видимый текст кнопки), ")
        sb.append("type (текст в активное поле), global (одно из: ${GLOBALS.joinToString(", ")}), ")
        sb.append("dial (номер цифрами), url (полный адрес или https://www.google.com/search?q=...). ")
        sb.append("Не больше 6 шагов. «Открой телеграм и напиши привет» = open_app Telegram, затем type привет.\n")
        sb.append("Не вводи пароли, PIN-коды и данные карт, не подтверждай платежи — скажи, что это нужно сделать вручную.\n")
        sb.append("Погоду, таймеры, будильники и громкость телефон обрабатывает сам; ")
        sb.append("если спросят — ответь коротко по своим знаниям и скажи, что актуальных данных у тебя нет.\n")
        if (prefs.homeCity.isNotBlank()) sb.append("Домашний город пользователя: ${prefs.homeCity}.\n")
        if (notes.isNotEmpty()) {
            sb.append("Пользователь просил запомнить: ${notes.joinToString("; ")}.\n")
        }
        return sb.toString()
    }

    private fun buildBody(prefs: Prefs, text: String): RequestBody {
        val messages = JSONArray()
        synchronized(history) {
            for ((role, content) in history) {
                messages.put(JSONObject().put("role", role).put("content", content))
            }
        }
        messages.put(JSONObject().put("role", "user").put("content", text))

        val json = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 600)
            .put("system", systemPrompt(prefs))
            .put("tools", JSONArray().put(JSONObject(TOOL_JSON)))
            .put("tool_choice", JSONObject().put("type", "auto"))
            .put("messages", messages)
        return json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    }

    fun ask(context: Context, apiKey: String, text: String, callback: ServerClient.ServerCallback) {
        val prefs = Prefs(context)
        val request = try {
            Request.Builder()
                .url(ENDPOINT)
                .header("x-api-key", apiKey.trim())
                .header("anthropic-version", API_VERSION)
                .post(buildBody(prefs, text))
                .build()
        } catch (e: Exception) {
            callback.onFailure("Неверный ключ Claude")
            return
        }

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.onFailure("Нет связи с Claude")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    val raw = r.body?.string() ?: ""
                    if (!r.isSuccessful) {
                        callback.onFailure(errorText(r.code, raw))
                        return
                    }
                    try {
                        callback.onSuccess(parse(raw, text))
                    } catch (e: Exception) {
                        callback.onFailure("Не разобрал ответ Claude")
                    }
                }
            }
        })
    }

    private fun errorText(code: Int, raw: String): String {
        val detail = try {
            JSONObject(raw).optJSONObject("error")?.optString("message") ?: ""
        } catch (e: Exception) {
            ""
        }
        return when (code) {
            401 -> "Неверный ключ Claude"
            403 -> "Ключ Claude не имеет доступа"
            429 -> "Слишком много запросов к Claude"
            529, 500, 502, 503 -> "Claude сейчас перегружен"
            else -> "Ошибка Claude $code ${detail.take(100)}".trim()
        }
    }

    private fun parse(raw: String, userText: String): ServerClient.Reply {
        val content = JSONObject(raw).optJSONArray("content") ?: JSONArray()
        val texts = StringBuilder()
        var toolSay = ""
        val steps = ArrayList<Step>()

        for (i in 0 until content.length()) {
            val block = content.optJSONObject(i)
            if (block == null) {
                // пропускаем
            } else if (block.optString("type") == "text") {
                texts.append(block.optString("text")).append(' ')
            } else if (block.optString("type") == "tool_use" &&
                block.optString("name") == "phone_commands"
            ) {
                val input = block.optJSONObject("input")
                if (input != null) {
                    toolSay = input.optString("say", "").trim()
                    val array = input.optJSONArray("steps")
                    if (array != null) {
                        for (j in 0 until array.length()) {
                            val item = array.optJSONObject(j) ?: continue
                            val step = cleanStep(item.optString("action"), item.optString("value"))
                            if (step != null && steps.size < 6) steps.add(step)
                        }
                    }
                }
            }
        }

        val say = toolSay.ifBlank { texts.toString().trim() }.take(600)

        synchronized(history) {
            history.add("user" to userText)
            history.add("assistant" to say.ifBlank { "Готово." })
            while (history.size > 8) history.removeAt(0)
        }
        return ServerClient.Reply(say, steps)
    }

    private fun cleanStep(action: String, value: String): Step? {
        val a = action.trim()
        var v = value.trim()
        if (a !in ACTIONS || v.isEmpty()) return null
        if (a == "global" && v.lowercase() !in GLOBALS) return null
        if (a == "url" && !v.lowercase().startsWith("http")) v = "https://$v"
        return Step(a, v)
    }
}
