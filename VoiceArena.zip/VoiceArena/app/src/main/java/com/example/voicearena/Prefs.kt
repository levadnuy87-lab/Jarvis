package com.example.voicearena

import android.content.Context
import org.json.JSONArray

/** Настройки и заметки. Хранятся только на этом телефоне. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("voicearena", Context.MODE_PRIVATE)

    private fun str(key: String): String = sp.getString(key, "") ?: ""
    private fun put(key: String, value: String) {
        sp.edit().putString(key, value.trim()).apply()
    }

    /** Адрес собственного сервера (необязательно). */
    var serverUrl: String
        get() = str("server_url")
        set(value) = put("server_url", value)

    var token: String
        get() = str("token")
        set(value) = put("token", value)

    /** Ключ Claude API: «мозг» работает прямо с телефона. */
    var apiKey: String
        get() = str("api_key")
        set(value) = put("api_key", value)

    /** Бесплатный ключ Picovoice: слово «Джарвис» распознаётся на устройстве. */
    var picoKey: String
        get() = str("pico_key")
        set(value) = put("pico_key", value)

    /** Город по умолчанию для погоды. */
    var homeCity: String
        get() = str("home_city")
        set(value) = put("home_city", value)

    /** Отвечать голосом. */
    var voiceReplies: Boolean
        get() = sp.getBoolean("voice_replies", true)
        set(value) {
            sp.edit().putBoolean("voice_replies", value).apply()
        }

    /** «Режим колонки»: не давать процессору засыпать, пока Джарвис слушает. */
    var speakerMode: Boolean
        get() = sp.getBoolean("speaker_mode", true)
        set(value) {
            sp.edit().putBoolean("speaker_mode", value).apply()
        }

    // ---------- заметки («Джарвис, запомни ...») ----------

    fun notes(): List<String> {
        return try {
            val array = JSONArray(sp.getString("notes", "[]") ?: "[]")
            (0 until array.length()).map { array.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addNote(note: String) {
        val text = note.trim()
        if (text.isEmpty()) return
        val updated = (notes() + text).takeLast(50)
        sp.edit().putString("notes", JSONArray(updated).toString()).apply()
    }

    fun clearNotes() {
        sp.edit().remove("notes").apply()
    }
}
