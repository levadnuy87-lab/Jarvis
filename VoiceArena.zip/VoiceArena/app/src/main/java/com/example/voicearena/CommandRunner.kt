package com.example.voicearena

import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * Что делает Джарвис с фразой:
 *  1) навыки без интернета (время, таймер, погода, громкость...) — Skills;
 *  2) если есть ключ Claude (или свой сервер) — спрашивает Claude;
 *  3) если связи нет — простые команды разбирает LocalParser.
 */
object CommandRunner {

    private val main = Handler(Looper.getMainLooper())

    /**
     * speakFailure = false — не говорить «Не понял» (в окне уточнений Джарвис
     * может услышать посторонний разговор).
     */
    fun handle(
        context: Context,
        text: String,
        onStatus: (String) -> Unit,
        speakFailure: Boolean = true
    ) {
        val app = context.applicationContext
        val prefs = Prefs(app)

        // 1. Встроенные навыки
        val handled = Skills.handle(app, text) { answer ->
            if (answer.isBlank()) {
                onStatus("«$text»\nГотово")
            } else {
                onStatus("«$text»\n$answer")
                Speaker.speak(app, answer)
            }
        }
        if (handled) return

        // 2. Claude: ключ в приложении или свой сервер
        val callback = object : ServerClient.ServerCallback {
            override fun onSuccess(reply: ServerClient.Reply) {
                main.post { finish(app, text, reply.steps, reply.say, onStatus, speakFailure) }
            }

            override fun onFailure(message: String) {
                main.post { local(app, text, message, onStatus, speakFailure) }
            }
        }
        if (prefs.apiKey.isNotBlank()) {
            onStatus("«$text»\nДумаю...")
            ClaudeClient.ask(app, prefs.apiKey, text, callback)
            return
        }
        if (prefs.serverUrl.isNotBlank()) {
            onStatus("«$text»\nДумаю...")
            ServerClient.send(prefs.serverUrl, prefs.token, text, callback)
            return
        }

        // 3. Без «мозга»: только простые команды
        local(app, text, "", onStatus, speakFailure)
    }

    private fun local(
        context: Context,
        text: String,
        problem: String,
        onStatus: (String) -> Unit,
        speakFailure: Boolean
    ) {
        val steps = LocalParser.parse(context, text)
        if (steps.isEmpty()) {
            val hint = if (problem.isNotBlank()) "$problem\n" else ""
            onStatus("$hint«$text» — не понял")
            if (speakFailure) {
                val needBrain = Prefs(context).apiKey.isBlank()
                Speaker.speak(
                    context,
                    if (problem.isNotBlank()) "Нет связи с Claude" else if (needBrain) "Не понял. Для сложных вопросов добавьте ключ Claude в настройках" else "Не понял"
                )
            }
            return
        }
        onStatus(if (problem.isNotBlank()) "$problem\nВыполняю локально" else "«$text»\nВыполняю…")
        runSteps(context, steps, onStatus)
    }

    private fun finish(
        context: Context,
        heard: String,
        steps: List<Step>,
        say: String,
        onStatus: (String) -> Unit,
        speakFailure: Boolean
    ) {
        if (say.isNotBlank()) Speaker.speak(context, say)

        if (steps.isEmpty()) {
            if (say.isNotBlank()) {
                onStatus("«$heard»\n$say")
            } else {
                onStatus("Не понял: «$heard»")
                if (speakFailure) Speaker.speak(context, "Не понял")
            }
            return
        }
        onStatus(if (say.isNotBlank()) "«$heard»\n$say" else "«$heard»\nВыполняю…")
        runSteps(context, steps, onStatus)
    }

    private fun runSteps(context: Context, steps: List<Step>, onStatus: (String) -> Unit) {
        val service = VoiceAccessibilityService.instance
        if (service == null) {
            onStatus("Служба доступности выключена. Включите её в приложении.")
            Speaker.speak(context, "Включите службу доступности")
            return
        }
        service.runSteps(steps)
    }
}
