package com.example.voicearena

/** Один шаг команды: action — open_app, click, type, dial, url, global, timer, alarm, media, torch. */
data class Step(val action: String, val value: String)
