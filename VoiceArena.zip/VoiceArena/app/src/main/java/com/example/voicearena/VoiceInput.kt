package com.example.voicearena

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat

/** Одно распознавание речи по кнопке; результат уходит в CommandRunner. */
class VoiceInput(
    private val context: Context,
    private val onStatus: (String) -> Unit
) {
    var onListening: ((Boolean) -> Unit)? = null
    private var recognizer: SpeechRecognizer? = null

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onStatus("На телефоне нет службы распознавания речи (нужно приложение Google)")
            return
        }
        destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(listener)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun errorText(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "Не расслышал, повторите"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ничего не услышал"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознавание занято, повторите"
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Нет сети для распознавания речи"
        SpeechRecognizer.ERROR_AUDIO -> "Ошибка записи звука"
        else -> "Ошибка распознавания: $code"
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            onListening?.invoke(true)
            onStatus("Слушаю...")
        }

        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            onListening?.invoke(false)
            onStatus("Обрабатываю...")
        }

        override fun onError(error: Int) {
            onListening?.invoke(false)
            onStatus(errorText(error))
        }

        override fun onResults(results: Bundle?) {
            onListening?.invoke(false)
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                onStatus("Не расслышал")
                return
            }
            // Если сказали «Джарвис, открой ютуб» кнопкой — слово активации отбрасываем.
            val command = WakeWord.extractCommand(text)?.ifBlank { null } ?: text
            CommandRunner.handle(context, command, onStatus)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
