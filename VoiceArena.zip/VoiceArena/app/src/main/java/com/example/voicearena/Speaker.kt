package com.example.voicearena

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Озвучка ответов. Вызывать можно из любого потока. */
object Speaker {

    private class Pending(val text: String, val done: (() -> Unit)?)

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false
    private var initializing = false
    private val queue = ArrayList<Pending>()
    private val callbacks = HashMap<String, () -> Unit>()
    private var counter = 0
    private var active = 0

    /** Вызывается в главном потоке: true — началась речь, false — речь закончилась. */
    var onSpeakingChanged: ((Boolean) -> Unit)? = null

    val isReady: Boolean
        get() = ready

    /** Заранее запустить движок озвучки, чтобы первая фраза не задерживалась. */
    fun init(context: Context) {
        val app = context.applicationContext
        main.post { ensureEngine(app) }
    }

    /** Произнести текст; done вызывается, когда речь закончилась (или озвучка недоступна). */
    fun speak(context: Context, text: String, done: (() -> Unit)? = null) {
        val app = context.applicationContext
        main.post { speakOnMain(app, text, done) }
    }

    /** Прервать речь. Ожидающие done не вызываются. */
    fun stop() {
        main.post {
            callbacks.clear()
            queue.clear()
            tts?.stop()
            val wasSpeaking = active > 0
            active = 0
            if (wasSpeaking) onSpeakingChanged?.invoke(false)
        }
    }

    // ---------- внутреннее ----------

    private fun begin() {
        active += 1
        if (active == 1) onSpeakingChanged?.invoke(true)
    }

    private fun end() {
        if (active > 0) {
            active -= 1
            if (active == 0) onSpeakingChanged?.invoke(false)
        }
    }

    private fun ensureEngine(app: Context) {
        if (tts != null || initializing) return
        initializing = true
        tts = TextToSpeech(app) { status -> main.post { onInit(status) } }
    }

    private fun speakOnMain(app: Context, text: String, done: (() -> Unit)?) {
        if (text.isBlank()) {
            done?.invoke()
            return
        }
        begin()
        if (ready) {
            say(text, done)
            return
        }
        queue.add(Pending(text, done))
        ensureEngine(app)
    }

    private fun onInit(status: Int) {
        initializing = false
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            tts = null
            val items = ArrayList(queue)
            queue.clear()
            for (item in items) {
                end()
                item.done?.invoke()
            }
            return
        }
        // Если русского голоса нет, говорим тем, что есть: установите русский голос в настройках речи.
        engine.setLanguage(Locale("ru", "RU"))
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        engine.setOnUtteranceProgressListener(progress)
        ready = true

        val items = ArrayList(queue)
        queue.clear()
        for (item in items) say(item.text, item.done)
    }

    private fun say(text: String, done: (() -> Unit)?) {
        val engine = tts
        if (engine == null) {
            end()
            done?.invoke()
            return
        }
        counter += 1
        val id = "u$counter"
        callbacks[id] = {
            end()
            done?.invoke()
        }
        // страховка: если движок не сообщит о завершении, не зависаем навсегда
        main.postDelayed({ callbacks.remove(id)?.invoke() }, 4000L + text.length * 90L)

        val code = engine.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        if (code != TextToSpeech.SUCCESS) {
            callbacks.remove(id)?.invoke()
        }
    }

    private fun complete(id: String?) {
        main.post {
            if (id != null) callbacks.remove(id)?.invoke()
        }
    }

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            complete(utteranceId)
        }

        @Suppress("OVERRIDE_DEPRECATION")
        override fun onError(utteranceId: String?) {
            complete(utteranceId)
        }

        override fun onStop(utteranceId: String?, interrupted: Boolean) {
            complete(utteranceId)
        }
    }
}
