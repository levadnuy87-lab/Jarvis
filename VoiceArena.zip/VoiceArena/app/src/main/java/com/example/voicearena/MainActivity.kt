package com.example.voicearena

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var wakeButton: Button
    private lateinit var apiKey: EditText
    private lateinit var picoKey: EditText
    private lateinit var homeCity: EditText
    private lateinit var voiceCheck: CheckBox
    private lateinit var serverUrl: EditText
    private lateinit var token: EditText
    private lateinit var prefs: Prefs

    private val voice by lazy { VoiceInput(this) { msg -> status.text = msg } }

    private var afterPermission: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        if (hasMic()) {
            afterPermission?.invoke()
        } else {
            Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_SHORT).show()
        }
        afterPermission = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        status = findViewById(R.id.status)
        wakeButton = findViewById(R.id.wakeButton)
        apiKey = findViewById(R.id.apiKey)
        picoKey = findViewById(R.id.picoKey)
        homeCity = findViewById(R.id.homeCity)
        voiceCheck = findViewById(R.id.voiceCheck)
        serverUrl = findViewById(R.id.serverUrl)
        token = findViewById(R.id.token)

        apiKey.setText(prefs.apiKey)
        picoKey.setText(prefs.picoKey)
        homeCity.setText(prefs.homeCity)
        voiceCheck.isChecked = prefs.voiceReplies
        serverUrl.setText(prefs.serverUrl)
        token.setText(prefs.token)

        Speaker.init(this)

        wakeButton.setOnClickListener { toggleWake() }
        findViewById<Button>(R.id.listenButton).setOnClickListener { startListening() }

        findViewById<Button>(R.id.testVoiceButton).setOnClickListener {
            saveSettings()
            Speaker.speak(this, "Здравствуйте! Я Джарвис. Голос работает.")
            wakeButton.postDelayed({
                if (!Speaker.isReady) {
                    Toast.makeText(
                        this,
                        "Голос недоступен: установите «Службы речи Google» и русский язык",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }, 1500)
        }

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.appInfoButton).setOnClickListener {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
        findViewById<Button>(R.id.overlayButton).setOnClickListener {
            val service = VoiceAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Сначала включите службу доступности", Toast.LENGTH_LONG).show()
            } else {
                service.toggleOverlay()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        voice.destroy()
        super.onDestroy()
    }

    // ---------- состояние ----------

    private fun saveSettings() {
        prefs.apiKey = apiKey.text.toString()
        prefs.picoKey = picoKey.text.toString()
        prefs.homeCity = homeCity.text.toString()
        prefs.voiceReplies = voiceCheck.isChecked
        prefs.serverUrl = serverUrl.text.toString()
        prefs.token = token.text.toString()
    }

    private fun updateStatus() {
        val wake = WakeWordService.instance
        val lines = ArrayList<String>()
        lines.add(
            if (isServiceEnabled()) "Служба доступности: включена"
            else "Служба доступности: ВЫКЛЮЧЕНА — нажмите кнопку «Включить службу доступности»"
        )
        lines.add(
            if (wake == null) "Активация «Джарвис»: выключена"
            else if (wake.enginePorcupine) "Активация «Джарвис»: слушаю (Picovoice)"
            else "Активация «Джарвис»: слушаю (Google)"
        )
        lines.add(
            if (prefs.apiKey.isNotBlank()) "Мозг Claude: подключён" else "Мозг Claude: нет ключа (базовые команды работают)"
        )
        status.text = lines.joinToString("\n")
        wakeButton.text = if (wake != null) {
            "Выключить активацию «Джарвис»"
        } else {
            "Включить активацию «Джарвис»"
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, VoiceAccessibilityService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun hasMic(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun withPermissions(action: () -> Unit) {
        val missing = mutableListOf<String>()
        if (!hasMic()) missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        // контакты нужны только для «позвони маме»; без них остальное работает
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            missing.add(Manifest.permission.READ_CONTACTS)
        }
        if (missing.isEmpty()) {
            action()
            return
        }
        afterPermission = action
        permissionLauncher.launch(missing.toTypedArray())
    }

    private fun requireService(): Boolean {
        if (isServiceEnabled()) return true
        Toast.makeText(this, "Сначала включите службу Voice Arena", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        return false
    }

    // ---------- действия ----------

    private fun toggleWake() {
        saveSettings()
        if (WakeWordService.isRunning) {
            stopService(Intent(this, WakeWordService::class.java))
            wakeButton.postDelayed({ updateStatus() }, 400)
            return
        }
        if (!requireService()) return
        withPermissions {
            ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
            wakeButton.postDelayed({ updateStatus() }, 900)
        }
    }

    private fun startListening() {
        saveSettings()
        if (!requireService()) return
        withPermissions {
            val wake = WakeWordService.instance
            if (wake != null) {
                status.text = "Слушаю команду…"
                wake.activateNow()
            } else {
                voice.start()
            }
        }
    }
}
