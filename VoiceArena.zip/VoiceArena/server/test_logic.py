"""Запуск: python test_logic.py"""
from types import SimpleNamespace as NS

from logic import build_reply, clean_steps, extract_tool_input

# 1. Нормальный ответ с цепочкой
data = {"say": "Открываю Telegram", "steps": [
    {"action": "open_app", "value": "Telegram"},
    {"action": "type", "value": "привет"},
]}
assert build_reply(data) == {"say": "Открываю Telegram", "steps": data["steps"]}

# 2. Мусор отфильтровывается: неизвестное действие, пустое значение, чужой global
steps = clean_steps([
    {"action": "rm_rf", "value": "/"},
    {"action": "click", "value": "  "},
    {"action": "global", "value": "выключить"},
    {"action": "global", "value": "Домой"},
    "строка", None,
])
assert steps == [{"action": "global", "value": "Домой"}], steps

# 3. URL без схемы получает https://
assert clean_steps([{"action": "url", "value": "example.com"}])[0]["value"] == "https://example.com"

# 4. Лимит шагов
many = [{"action": "click", "value": str(i)} for i in range(20)]
assert len(clean_steps(many)) == 6

# 5. Достаём tool_use из объектов и из словарей
blocks_obj = [NS(type="text", text="..."), NS(type="tool_use", name="phone_commands", input=data)]
blocks_dict = [{"type": "tool_use", "name": "phone_commands", "input": data}]
assert extract_tool_input(blocks_obj) == data
assert extract_tool_input(blocks_dict) == data
assert extract_tool_input([NS(type="text", text="нет инструмента")]) is None
assert extract_tool_input([NS(type="tool_use", name="other", input=data)]) is None

# 6. Нет ответа модели -> безопасное «не понял»
assert build_reply(None) == {"say": "Не понял команду", "steps": []}
assert build_reply({"steps": []})["say"] == "Не понял команду"
assert build_reply({"steps": [{"action": "click", "value": "OK"}]})["say"] == "Выполняю"

print("все проверки сервера прошли")
