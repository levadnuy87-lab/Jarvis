"""Чистая логика без внешних библиотек: проверка и очистка ответа модели."""

ACTIONS = ("open_app", "click", "type", "global", "dial", "url")
GLOBAL_VALUES = ("домой", "назад", "недавние", "уведомления", "быстрые настройки")
MAX_STEPS = 6


def clean_steps(raw, limit: int = MAX_STEPS) -> list:
    """Оставляет только допустимые шаги: известное действие и непустое значение."""
    if not isinstance(raw, list):
        return []
    steps = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        action = str(item.get("action", "")).strip()
        value = str(item.get("value", "")).strip()
        if action not in ACTIONS or not value:
            continue
        if action == "global" and value.lower() not in GLOBAL_VALUES:
            continue
        if action == "url" and not value.lower().startswith(("http://", "https://")):
            value = "https://" + value
        steps.append({"action": action, "value": value})
        if len(steps) >= limit:
            break
    return steps


def extract_tool_input(blocks, tool_name: str = "phone_commands"):
    """Достаёт аргументы вызванного инструмента из content-блоков ответа Claude."""
    for block in blocks or []:
        if isinstance(block, dict):
            kind, name, data = block.get("type"), block.get("name"), block.get("input")
        else:
            kind = getattr(block, "type", None)
            name = getattr(block, "name", None)
            data = getattr(block, "input", None)
        if kind == "tool_use" and name == tool_name and isinstance(data, dict):
            return data
    return None


def build_reply(data) -> dict:
    """Превращает ответ модели в {say, steps}; при мусоре возвращает «не понял»."""
    if not isinstance(data, dict):
        return {"say": "Не понял команду", "steps": []}
    steps = clean_steps(data.get("steps"))
    say = str(data.get("say", "")).strip()[:120]
    if not say:
        say = "Выполняю" if steps else "Не понял команду"
    return {"say": say, "steps": steps}
