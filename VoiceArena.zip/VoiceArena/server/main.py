"""Сервер Voice Arena: принимает текст с телефона, спрашивает Claude, возвращает шаги."""
import hmac
import os
from functools import lru_cache

import anthropic
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from logic import ACTIONS, GLOBAL_VALUES, MAX_STEPS, build_reply, extract_tool_input

load_dotenv()

MODEL = os.getenv("CLAUDE_MODEL", "claude-haiku-5-5")
APP_TOKEN = os.getenv("APP_TOKEN", "").strip()

app = FastAPI(title="Voice Arena Server")


class CommandRequest(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class Step(BaseModel):
    action: str
    value: str


class CommandResponse(BaseModel):
    say: str
    steps: list[Step]


SYSTEM_PROMPT = f"""Ты — мозг голосового ассистента «Джарвис» на Android-телефоне.
Пользователь говорит по-русски. Переведи его фразу в короткую цепочку шагов
для службы доступности и ответь ТОЛЬКО вызовом инструмента phone_commands.

Шаги (action → value):
- open_app — запустить приложение; value = название так, как оно подписано на телефоне (YouTube, Telegram, Камера).
- click — нажать элемент на экране; value = видимый текст кнопки (Отправить, Войти).
- type — ввести текст в активное поле; value = сам текст.
- global — системная кнопка; value строго одно из: {", ".join(GLOBAL_VALUES)}.
- dial — открыть набор номера; value = номер цифрами.
- url — открыть сайт или поиск; value = полный адрес (для поиска: https://www.google.com/search?q=...).

Правила:
- Не больше {MAX_STEPS} шагов. Между шагами интерфейс сам ждёт, паузы добавлять не нужно.
- «Открой телеграм и напиши привет» = open_app Telegram, затем type привет.
- say — одна короткая фраза-подтверждение по-русски (до 80 символов).
- Если фраза непонятна или это просто разговор — steps пустой, в say короткий ответ.
- Не вводи пароли, PIN-коды и данные банковских карт, не подтверждай платежи и переводы:
  в таких случаях steps пустой, в say объясни, что это нужно сделать вручную.
"""

TOOL = {
    "name": "phone_commands",
    "description": "Список шагов, которые телефон должен выполнить, и короткая фраза-подтверждение.",
    "input_schema": {
        "type": "object",
        "properties": {
            "say": {"type": "string", "description": "Короткое подтверждение по-русски, до 80 символов"},
            "steps": {
                "type": "array",
                "maxItems": MAX_STEPS,
                "items": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": list(ACTIONS)},
                        "value": {"type": "string"},
                    },
                    "required": ["action", "value"],
                },
            },
        },
        "required": ["say", "steps"],
    },
}


@lru_cache(maxsize=1)
def get_client() -> anthropic.Anthropic:
    # ключ берётся из переменной окружения ANTHROPIC_API_KEY
    return anthropic.Anthropic()


def check_token(authorization: str | None) -> None:
    if not APP_TOKEN:
        return
    expected = f"Bearer {APP_TOKEN}"
    if not authorization or not hmac.compare_digest(authorization.strip(), expected):
        raise HTTPException(status_code=401, detail="Неверный токен")


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL, "token_required": bool(APP_TOKEN)}


# обычная функция (не async): FastAPI запустит её в потоке и не заблокирует сервер
@app.post("/execute", response_model=CommandResponse)
def execute(req: CommandRequest, authorization: str | None = Header(default=None)):
    check_token(authorization)
    try:
        response = get_client().messages.create(
            model=MODEL,
            max_tokens=400,
            system=SYSTEM_PROMPT,
            tools=[TOOL],
            tool_choice={"type": "tool", "name": "phone_commands"},
            messages=[{"role": "user", "content": req.text}],
        )
    except anthropic.APIError as e:
        raise HTTPException(status_code=502, detail=f"Ошибка Claude API: {e}")
    return build_reply(extract_tool_input(response.content))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000)
